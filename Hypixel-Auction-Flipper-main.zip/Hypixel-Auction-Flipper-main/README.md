# Hypixel Auction House Flipper

# Features:

- Custom filters (Catergory, Name, Enchantment..)
- Auction Copy Paste Link
- Profit, Cost, LBIN information
- Type of Auction (Snipe or under valued item)
- Sales/Day check
- Mininimal profit in value and percentage
- Automatic price refresher
- Discord Webhook integration
- Ability to make some high tier enchantments worthless (like Looking 4, Luck 6 etc..)
- Bad Enchantment filter
- And more.. 
